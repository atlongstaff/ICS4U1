public class ExampleQ1 {
	public static void main(String[] args){
		
	int num = 5;
	for (int i=1; i<=20; i++) {
		System.out.println(num); 	

		num += 5;
	}
}
}